import { createHash, randomUUID } from 'node:crypto';
import { NextResponse } from 'next/server';
import { isValidLanguage } from '@/lib/i18n/config';
import { inquiryLimits, type InquiryFields, type InquirySource } from '@/lib/inquiry';
import { deliverInquiry, InquiryDeliveryError, sesConfig } from '@/lib/tencent-ses';

export const runtime = 'nodejs';
const ttl = 10 * 60 * 1000;
const attempts = new Map<string, { count: number; expires: number }>();
const submissions = new Map<string, { hash: string; expires: number; delivery: Promise<string> }>();
const digest = (value: string) => createHash('sha256').update(value).digest('hex');
const reply = (status: number, body: object) => NextResponse.json(body, { status, headers: { 'Cache-Control': 'no-store', ...(status === 429 ? { 'Retry-After': '600' } : {}) } });

function limit(key: string, maximum: number) {
  const now = Date.now();
  for (const [key, bucket] of attempts) if (bucket.expires <= now) attempts.delete(key);
  const bucket = attempts.get(key) || { count: 0, expires: now + ttl };
  bucket.count++;
  attempts.set(key, bucket);
  return bucket.count <= maximum;
}

async function readBody(request: Request): Promise<unknown> {
  const reader = request.body?.getReader();
  if (!reader) throw new Error('empty');
  const chunks: Uint8Array[] = [];
  let size = 0;
  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    size += value.byteLength;
    if (size > 30000) { await reader.cancel(); throw new Error('too_large'); }
    chunks.push(value);
  }
  return JSON.parse(Buffer.concat(chunks).toString('utf8'));
}

export async function POST(request: Request) {
  const origin = request.headers.get('origin');
  const localOrigin = new URL(request.url).origin;
  const allowed = ['https://szmagicchip.com', ...(process.env.NODE_ENV === 'production' ? [] : [localOrigin])];
  if (!origin || !allowed.includes(origin)) return reply(403, { error: 'invalid_origin' });
  if (request.headers.get('content-type')?.split(';')[0].trim() !== 'application/json') return reply(415, { error: 'invalid_content_type' });
  // A global budget also protects deployments without a trusted proxy IP header.
  if (!limit('global', 100)) return reply(429, { error: 'rate_limited' });
  if (process.env.INQUIRY_TRUST_PROXY === 'true') {
    const ip = request.headers.get('x-real-ip') || 'unknown';
    if (!limit(`ip:${digest(ip)}`, 10)) return reply(429, { error: 'rate_limited' });
  }
  let body: unknown;
  try { body = await readBody(request); } catch { return reply(400, { error: 'invalid_request' }); }
  if (!body || typeof body !== 'object' || Array.isArray(body)) return reply(400, { error: 'invalid_request' });
  const input = body as Record<string, unknown>;
  if (input.website !== '' || !isValidLanguage(String(input.language)) || !['home_form', 'contact_form'].includes(String(input.source))
    || typeof input.requestId !== 'string' || !/^[a-f0-9-]{36}$/i.test(input.requestId)) return reply(400, { error: 'invalid_request' });
  const fields: Record<string, string> = {};
  for (const [key, maximum] of Object.entries(inquiryLimits)) {
    const value = input[key] ?? '';
    if (typeof value !== 'string' || value.length > maximum || /[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/.test(value)
      || (key !== 'message' && /[\r\n]/.test(value))) return reply(400, { error: 'invalid_fields' });
    fields[key] = value.trim();
  }
  if (!fields.name || !fields.message || !/^[^\s@<>(),;:"\\]+@[^\s@<>(),;:"\\]+\.[^\s@<>(),;:"\\]+$/.test(fields.email)
    || (input.source === 'contact_form' && (!fields.company || !fields.inquiryType))) return reply(400, { error: 'invalid_fields' });

  const payloadHash = digest(JSON.stringify([fields, input.source, input.language]));
  for (const [key, submission] of submissions) if (submission.expires <= Date.now()) submissions.delete(key);
  const existing = submissions.get(input.requestId);
  if (existing && existing.hash !== payloadHash) return reply(409, { error: 'request_changed' });
  if (!existing && !limit(`email:${digest(fields.email.toLowerCase())}`, 5)) return reply(429, { error: 'rate_limited' });
  try {
    sesConfig();
    const delivery = existing?.delivery || (async () => {
      const reference = randomUUID();
      await deliverInquiry(fields as InquiryFields, input.source as InquirySource, String(input.language), reference);
      return reference;
    })();
    if (!existing) submissions.set(input.requestId, { hash: payloadHash, expires: Date.now() + ttl, delivery });
    return reply(200, { ok: true, reference: await delivery });
  } catch (error) {
    submissions.delete(input.requestId);
    // Never log the request body, credentials, or raw provider error.
    console.error('Inquiry submission failed:', error instanceof InquiryDeliveryError ? error.code : 'delivery_unavailable');
    return reply(503, { error: 'delivery_unavailable' });
  }
}
