'use client';

import { CheckCircle2 } from 'lucide-react';
import { useLanguage } from '@/lib/i18n/LanguageContext';
import { inquiryCopy } from '@/lib/inquiry';
import { actionButtonStyles } from '@/lib/action-button-styles';
import { createInquiryDraft } from '@/lib/email-inquiry';
import type { InquiryFields } from '@/lib/inquiry';

export function InquirySuccess({ reference, onReset }: { reference: string; onReset: () => void }) {
  const { language } = useLanguage();
  const copy = inquiryCopy[language];
  return <div role="status" aria-live="polite" tabIndex={-1} ref={node => node?.focus()} className="text-center">
    <CheckCircle2 className="mx-auto h-12 w-12 text-emerald-600" aria-hidden="true" />
    <h2 className="mt-5 text-2xl font-bold text-slate-950">{copy.success}</h2>
    <p className="mt-3 text-slate-600">{copy.received}</p>
    <p className="mt-4 break-all text-xs text-slate-500">{copy.reference}: {reference}</p>
    <button type="button" onClick={onReset} className={`${actionButtonStyles.primary} mt-7`}>{copy.another}</button>
  </div>;
}

export function InquiryError({ error, fields }: { error: 'error' | 'rateLimit' | null; fields: InquiryFields }) {
  const { language } = useLanguage();
  if (!error) return null;
  const copy = inquiryCopy[language];
  return <div role="alert" className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-800">
    <p>{copy[error]}</p>
    <a href={createInquiryDraft(fields).mailto} className="mt-2 inline-block font-semibold underline">{copy.email}</a>
  </div>;
}

export function InquiryHoneypot({ value, onChange, id }: { value: string; onChange: (value: string) => void; id: string }) {
  return <div hidden aria-hidden="true">
    <label htmlFor={id}>Website</label>
    <input id={id} name="website" type="text" tabIndex={-1} autoComplete="off" value={value} onChange={event => onChange(event.target.value)} />
  </div>;
}
