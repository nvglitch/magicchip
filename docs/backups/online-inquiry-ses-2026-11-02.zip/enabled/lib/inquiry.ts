import type { Language } from '@/lib/i18n/config';

export type InquiryFields = {
  name: string;
  email: string;
  message: string;
  company?: string;
  inquiryType?: string;
  product?: string;
  quantity?: string;
};
export type InquirySource = 'contact_form' | 'home_form';
export const inquiryLimits = { name: 120, email: 254, company: 200, inquiryType: 120, product: 200, quantity: 120, message: 6000 } as const;

export const inquiryCopy = {
  en: { submit: 'Send inquiry', sending: 'Sending…', before: 'Submit your inquiry directly to our sales team. We use your details to respond to your request.', privacy: 'Privacy Policy', success: 'Thank you for your inquiry', received: 'Your inquiry has been submitted. Our sales team will follow up by email.', reference: 'Reference', another: 'Send another inquiry', error: 'We could not submit your inquiry. Your details are still here. Please try again, or contact us by email or WhatsApp.', rateLimit: 'Too many attempts. Please wait a few minutes and try again, or contact us by email or WhatsApp.', email: 'Email instead' },
  de: { submit: 'Anfrage senden', sending: 'Wird gesendet…', before: 'Senden Sie Ihre Anfrage direkt an unser Vertriebsteam. Wir verwenden Ihre Angaben zur Bearbeitung Ihrer Anfrage.', privacy: 'Datenschutzerklärung', success: 'Vielen Dank für Ihre Anfrage', received: 'Ihre Anfrage wurde übermittelt. Unser Vertriebsteam meldet sich per E-Mail bei Ihnen.', reference: 'Referenz', another: 'Weitere Anfrage senden', error: 'Ihre Anfrage konnte nicht übermittelt werden. Ihre Angaben bleiben erhalten. Bitte versuchen Sie es erneut oder kontaktieren Sie uns per E-Mail oder WhatsApp.', rateLimit: 'Zu viele Versuche. Bitte warten Sie einige Minuten oder kontaktieren Sie uns per E-Mail oder WhatsApp.', email: 'Stattdessen per E-Mail' },
  fr: { submit: 'Envoyer la demande', sending: 'Envoi en cours…', before: 'Envoyez votre demande directement à notre équipe commerciale. Nous utilisons vos coordonnées pour y répondre.', privacy: 'Politique de confidentialité', success: 'Merci pour votre demande', received: 'Votre demande a été transmise. Notre équipe commerciale vous répondra par e-mail.', reference: 'Référence', another: 'Envoyer une autre demande', error: 'Votre demande n’a pas pu être transmise. Vos informations sont conservées dans le formulaire. Réessayez ou contactez-nous par e-mail ou WhatsApp.', rateLimit: 'Trop de tentatives. Patientez quelques minutes ou contactez-nous par e-mail ou WhatsApp.', email: 'Contacter par e-mail' },
  it: { submit: 'Invia richiesta', sending: 'Invio in corso…', before: 'Invia la richiesta direttamente al nostro team commerciale. Utilizziamo i tuoi dati per rispondere alla richiesta.', privacy: 'Informativa sulla privacy', success: 'Grazie per la richiesta', received: 'La richiesta è stata inoltrata. Il nostro team commerciale ti risponderà via e-mail.', reference: 'Riferimento', another: 'Invia un’altra richiesta', error: 'Non è stato possibile inoltrare la richiesta. I dati restano nel modulo. Riprova oppure contattaci via e-mail o WhatsApp.', rateLimit: 'Troppi tentativi. Attendi qualche minuto oppure contattaci via e-mail o WhatsApp.', email: 'Contatta via e-mail' },
  es: { submit: 'Enviar consulta', sending: 'Enviando…', before: 'Envíe su consulta directamente a nuestro equipo comercial. Usamos sus datos para responder a su solicitud.', privacy: 'Política de privacidad', success: 'Gracias por su consulta', received: 'Su consulta se ha enviado. Nuestro equipo comercial le responderá por correo electrónico.', reference: 'Referencia', another: 'Enviar otra consulta', error: 'No hemos podido enviar su consulta. Sus datos siguen en el formulario. Vuelva a intentarlo o contáctenos por correo o WhatsApp.', rateLimit: 'Demasiados intentos. Espere unos minutos o contáctenos por correo o WhatsApp.', email: 'Contactar por correo' },
} satisfies Record<Language, Record<string, string>>;
