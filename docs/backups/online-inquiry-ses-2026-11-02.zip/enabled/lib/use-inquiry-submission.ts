'use client';

import { useRef, useState } from 'react';
import { useLanguage } from '@/lib/i18n/LanguageContext';
import { trackSiteEvent } from '@/lib/analytics';
import type { InquiryFields, InquirySource } from '@/lib/inquiry';

export function useInquirySubmission(source: InquirySource) {
  const { language } = useLanguage();
  const [sending, setSending] = useState(false);
  const [reference, setReference] = useState('');
  const [error, setError] = useState<'error' | 'rateLimit' | null>(null);
  const [website, setWebsite] = useState('');
  const busy = useRef(false);
  const attempt = useRef({ payload: '', id: '' });

  async function submit(fields: InquiryFields) {
    if (busy.current) return;
    busy.current = true;
    setSending(true);
    setError(null);
    try {
      const payload = JSON.stringify({ ...fields, language, source, website });
      if (attempt.current.payload !== payload) attempt.current = { payload, id: crypto.randomUUID() };
      const response = await fetch('/api/inquiries', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...JSON.parse(payload), requestId: attempt.current.id }),
        signal: AbortSignal.timeout(25000),
      });
      const result = await response.json();
      if (!response.ok || result.ok !== true || typeof result.reference !== 'string' || !result.reference) {
        setError(response.status === 429 ? 'rateLimit' : 'error');
        return;
      }
      setReference(result.reference);
      trackSiteEvent('generate_lead', { source });
    } catch { setError('error'); }
    finally { busy.current = false; setSending(false); }
  }

  function reset() {
    setReference(''); setError(null); setWebsite('');
    attempt.current = { payload: '', id: '' };
  }
  return { submit, sending, reference, error, website, setWebsite, reset };
}
