import { createHash, createHmac } from 'node:crypto';
import type { InquiryFields, InquirySource } from '@/lib/inquiry';
import { legalCompany } from '@/lib/legal-company';

const host = 'ses.tencentcloudapi.com';
const contentType = 'application/json; charset=utf-8';
const hash = (value: string) => createHash('sha256').update(value).digest('hex');
const hmac = (key: string | Buffer, value: string) => createHmac('sha256', key).update(value).digest();

// Tencent Cloud API 3.0 TC3 signing. Credentials remain on the server.
export function sesHeaders(body: string, secretId: string, secretKey: string, region: string, timestamp = Math.floor(Date.now() / 1000)) {
  const date = new Date(timestamp * 1000).toISOString().slice(0, 10);
  const scope = `${date}/ses/tc3_request`;
  const signedHeaders = 'content-type;host;x-tc-action';
  const canonical = `POST\n/\n\ncontent-type:${contentType}\nhost:${host}\nx-tc-action:sendemail\n\n${signedHeaders}\n${hash(body)}`;
  const signingKey = hmac(hmac(hmac(`TC3${secretKey}`, date), 'ses'), 'tc3_request');
  const signature = createHmac('sha256', signingKey).update(`TC3-HMAC-SHA256\n${timestamp}\n${scope}\n${hash(canonical)}`).digest('hex');
  return {
    'Content-Type': contentType,
    Authorization: `TC3-HMAC-SHA256 Credential=${secretId}/${scope}, SignedHeaders=${signedHeaders}, Signature=${signature}`,
    'X-TC-Action': 'SendEmail', 'X-TC-Version': '2020-10-02',
    'X-TC-Region': region, 'X-TC-Timestamp': String(timestamp),
    ...(process.env.TENCENTCLOUD_SESSION_TOKEN ? { 'X-TC-Token': process.env.TENCENTCLOUD_SESSION_TOKEN } : {}),
  };
}

export class InquiryDeliveryError extends Error {
  constructor(public code: string) { super('Inquiry delivery failed'); }
}

export function sesConfig() {
  const { TENCENTCLOUD_SECRET_ID: secretId, TENCENTCLOUD_SECRET_KEY: secretKey, INQUIRY_SES_FROM: from, INQUIRY_SES_TEMPLATE_ID: template } = process.env;
  const region = process.env.INQUIRY_SES_REGION || 'ap-hongkong';
  if (!secretId || !secretKey || !from || !/^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/.test(from)
    || !template || !/^[1-9]\d*$/.test(template) || !Number.isSafeInteger(Number(template))
    || !['ap-hongkong', 'ap-guangzhou'].includes(region)) throw new InquiryDeliveryError('not_configured');
  return { secretId, secretKey, from, template: Number(template), region };
}

const escapeHtml = (value: string) => value.replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]!);

export async function deliverInquiry(fields: InquiryFields, source: InquirySource, language: string, reference: string) {
  const config = sesConfig();
  const variables = Object.fromEntries(Object.entries({ ...fields, source, language, reference }).map(([key, value]) => [key, escapeHtml(value || '-') ]));
  const body = JSON.stringify({
    FromEmailAddress: `MagicChip Website <${config.from}>`,
    Destination: [legalCompany.email], ReplyToAddresses: fields.email,
    Subject: `MagicChip website inquiry ${reference}`,
    Template: { TemplateID: config.template, TemplateData: JSON.stringify(variables) },
    TriggerType: 1,
  });
  const response = await fetch(`https://${host}/`, {
    method: 'POST', headers: sesHeaders(body, config.secretId, config.secretKey, config.region),
    body, signal: AbortSignal.timeout(15000), cache: 'no-store', redirect: 'error',
  });
  if (!response.ok) throw new InquiryDeliveryError('provider_http_error');
  const result = await response.json() as { Response?: { MessageId?: string; Error?: { Code?: string } } };
  if (result.Response?.Error || typeof result.Response?.MessageId !== 'string' || !result.Response.MessageId.trim()) {
    throw new InquiryDeliveryError('provider_rejected');
  }
}
