// Exercises the real route with an isolated environment and a mocked SES transport.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const ts = require('typescript');
const { randomUUID } = require('node:crypto');
const root = path.resolve(__dirname, '..');
const env = {
  NODE_ENV: 'production', TENCENTCLOUD_SECRET_ID: 'test-id', TENCENTCLOUD_SECRET_KEY: 'test-key',
  INQUIRY_SES_FROM: 'website@notify.example.com', INQUIRY_SES_TEMPLATE_ID: '123',
};
let mode = 'success';
let calls = [];
const warnings = [];
async function transport(url, options) {
  calls.push({ url, options });
  await new Promise(resolve => setTimeout(resolve, 5));
  if (mode === 'timeout') throw new Error('test timeout');
  const result = mode === 'rejected' ? { Response: { Error: { Code: 'FailedOperation' } } }
    : mode === 'empty' ? {} : { Response: { MessageId: 'mock-message-id' } };
  return new Response(JSON.stringify(result), { status: mode === 'http' ? 502 : 200 });
}
const cache = new Map();
function load(file) {
  const filename = path.resolve(root, file);
  if (cache.has(filename)) return cache.get(filename);
  const exports = {};
  cache.set(filename, exports);
  const code = ts.transpileModule(fs.readFileSync(filename, 'utf8'), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } }).outputText;
  vm.runInNewContext(code, {
    exports, Buffer, Request, Response, AbortSignal, Date, URL, fetch: transport, process: { env },
    console: { error: (...args) => warnings.push(args.join(' ')) },
    require(name) { return name.startsWith('@/') ? load(name.slice(2) + '.ts') : require(name); },
  }, { filename });
  return exports;
}
const { POST } = load('app/api/inquiries/route.ts');
const base = { name: 'Sample Buyer', email: 'buyer@example.com', company: 'Sample Ltd', inquiryType: 'Bulk purchase', product: 'MCAIPC2', quantity: '25', message: 'Please quote.\nDelivery to Berlin.', language: 'de', source: 'contact_form', website: '' };
function request(fields = {}, origin = 'https://szmagicchip.com', raw) {
  return new Request('https://szmagicchip.com/api/inquiries', {
    method: 'POST', headers: { Origin: origin, 'Content-Type': 'application/json' },
    body: raw ?? JSON.stringify({ ...base, requestId: randomUUID(), ...fields }),
  });
}
async function main() {
  assert.equal((await POST(request({}, 'https://other.example'))).status, 403);
  for (const fields of [{ name: '' }, { email: 'x\r\nBcc: attacker@example.com' }, { company: '' }, { inquiryType: '' }, { website: 'spam' }, { language: 'zh' }, { source: 'other' }, { requestId: 'bad' }, { message: 'x'.repeat(6001) }, { name: ['invalid'] }]) {
    assert.equal((await POST(request(fields))).status, 400);
  }
  assert.equal((await POST(request({}, undefined, '{broken'))).status, 400);
  assert.equal((await POST(request({}, undefined, 'x'.repeat(30001)))).status, 400);
  assert.equal((await POST(new Request('https://szmagicchip.com/api/inquiries', { method: 'POST', headers: { Origin: 'https://szmagicchip.com', 'Content-Type': 'text/plain' }, body: 'x' }))).status, 415);
  assert.equal(calls.length, 0);
  delete env.INQUIRY_SES_TEMPLATE_ID;
  assert.equal((await POST(request({ email: 'config@example.com' }))).status, 503);
  assert.equal(calls.length, 0);
  env.INQUIRY_SES_TEMPLATE_ID = '123';

  const requestId = randomUUID();
  const payload = { requestId, message: '<script>alert("test")</script>\nPlease quote.' };
  const [a, b] = await Promise.all([POST(request(payload)), POST(request(payload))]);
  assert.equal(a.status, 200); assert.equal(b.status, 200);
  assert.equal(a.headers.get('cache-control'), 'no-store');
  assert.deepEqual(await a.json(), await b.json());
  assert.equal(calls.length, 1, 'concurrent duplicate must send once');
  const sent = JSON.parse(calls[0].options.body);
  const variables = JSON.parse(sent.Template.TemplateData);
  assert.equal(calls[0].url, 'https://ses.tencentcloudapi.com/');
  assert.deepEqual(sent.Destination, ['klauslee@szmagicchip.com']);
  assert.equal(sent.ReplyToAddresses, base.email);
  assert.equal(sent.Template.TemplateID, 123);
  assert.equal(variables.company, base.company);
  assert.equal(variables.quantity, '25');
  assert.equal(variables.language, 'de');
  assert.match(variables.message, /&lt;script&gt;/);
  assert.doesNotMatch(variables.message, /<script>/);
  assert.match(calls[0].options.headers.Authorization, /^TC3-HMAC-SHA256 Credential=test-id\//);
  assert.equal((await POST(request(payload))).status, 200);
  assert.equal(calls.length, 1, 'retry after acceptance must not send twice');
  assert.equal((await POST(request({ ...payload, message: 'changed' }))).status, 409);

  for (const failure of ['rejected', 'empty', 'http', 'timeout']) {
    mode = failure;
    const response = await POST(request({ email: `${failure}@example.com` }));
    assert.equal(response.status, 503);
    assert.equal((await response.json()).ok, undefined);
  }
  mode = 'success';
  const home = await POST(request({ source: 'home_form', email: 'home@example.com', company: '', inquiryType: '' }));
  assert.equal(home.status, 200, 'home form does not require company or inquiry type');
  for (let count = 0; count < 5; count++) assert.equal((await POST(request({ email: 'limited@example.com' }))).status, 200);
  const limited = await POST(request({ email: 'limited@example.com' }));
  assert.equal(limited.status, 429);
  assert.equal(limited.headers.get('retry-after'), '600');
  assert.doesNotMatch(warnings.join(' '), /buyer@example|test-key|Please quote/);
  console.log('Inquiry checks passed: validation, origin, size, configuration, SES payload, escaping, accepted-only success, concurrent deduplication, fallback failures and rate limiting. No real email sent.');
}
main().catch(error => { console.error(error); process.exitCode = 1; });
