const assert = require('node:assert/strict');
const origin = process.env.TEST_ORIGIN || 'http://127.0.0.1:3109';
const phrases = {
  en: ['Compact workstations for local AI', 'Send inquiry'],
  de: ['Kompakte Arbeitsplatzrechner für lokale KI', 'Anfrage senden'],
  fr: ['Des postes de travail compacts pour l’IA locale', 'Envoyer la demande'],
  it: ['Workstation compatte per l’IA locale', 'Invia richiesta'],
  es: ['Estaciones de trabajo compactas para IA local', 'Enviar consulta'],
};
const visible = html => html.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, '').replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, '').replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ');
async function main() {
  for (const [language, [heading, submit]] of Object.entries(phrases)) {
    const category = await fetch(`${origin}/${language}/products/ai-mini-pc`);
    assert.equal(category.status, 200);
    const html = await category.text();
    assert(visible(html).includes(heading));
    if (language !== 'en') for (const old of ['Browse Models', 'View Applications', 'What defines', 'Where this category fits', 'Choose the right configuration', 'Three mainboard series with configurable', 'Local AI acceleration']) assert(!visible(html).includes(old), `${language}: English content remains: ${old}`);
    assert(html.includes(`rel="canonical" href="https://szmagicchip.com/${language}/products/ai-mini-pc"`));
    for (const alternate of [...Object.keys(phrases), 'x-default']) assert(html.includes(`hrefLang="${alternate}"`));
    for (const route of ['', '/contact']) {
      const response = await fetch(`${origin}/${language}${route}`);
      assert.equal(response.status, 200);
      const form = await response.text();
      assert(visible(form).includes(submit));
      assert(!visible(form).includes('Prepare Email'));
      assert(!visible(form).includes('This opens a draft'));
      assert(form.includes('maxLength="6000"'));
      assert(form.includes('aria-busy="false"'));
    }
  }
  // Invalid payload is rejected before any mail transport, even on a configured server.
  const response = await fetch(`${origin}/api/inquiries`, {
    method: 'POST', headers: { Origin: 'https://szmagicchip.com', 'Content-Type': 'application/json' },
    body: JSON.stringify({ name: '', email: 'invalid', message: '', source: 'home_form', language: 'en', website: '', requestId: require('node:crypto').randomUUID() }),
  });
  assert.equal(response.status, 400);
  assert.equal((await response.json()).ok, undefined);
  console.log('Five AI category pages and ten inquiry forms passed: localized visible content, canonical, six hreflang entries, field constraints and no draft-only CTA. Production API rejected an invalid payload before delivery. No real email sent.');
}
main().catch(error => { console.error(error); process.exitCode = 1; });
