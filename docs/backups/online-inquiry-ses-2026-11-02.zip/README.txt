MagicChip Tencent SES online inquiry snapshot, 2026-11-02.
This archive contains selected source files only. No credentials, node_modules, build output or Git metadata.
Online submission was suspended at the user's request. Current website uses email drafts.
Retain translation and SEO changes in the workspace.

To restore later:
1. Extract this archive to a temporary folder in the project.
2. From the project root run git apply --check <absolute-path-to>/online-inquiry.patch.
3. If the check passes, run git apply <absolute-path-to>/online-inquiry.patch.
4. If it fails, use base/ and enabled/ snapshots to merge into current source; do not overwrite unrelated future edits.
5. Follow enabled/docs/在线询盘与核心翻译-2026-11-02.md for SES setup. No new npm dependencies are required.
6. Run node scripts/test-inquiries.cjs, node scripts/test-analytics.cjs and npm run build. Then test real email delivery after configuration.

manifest.json records the baseline commit, per-file base/enabled SHA-256 and patch hash.
The original implementation report is reference-only and is not reapplied by the patch.
